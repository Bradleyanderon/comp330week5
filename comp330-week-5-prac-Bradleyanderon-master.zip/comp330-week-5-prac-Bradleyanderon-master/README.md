COMP330 Week 5 Prac

Files
    index.html
    style.css
    js/                 Javascript files
        game.js         Framework for game
        input.js        Input manager
        matrix.js       Matrix library
        debugging.js    Debugging libray
        circle.js       Class for drawing circles